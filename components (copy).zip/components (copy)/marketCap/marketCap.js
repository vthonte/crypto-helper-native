
import React, {useState} from 'react';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';




export default function MarketCap(props) {
  return (
    <View style={'container'}>

<Text>Market Cap (in USD) : </Text>
<View style={'neoBox'}><Text>{props.marketCap}</Text></View>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    alignItems: 'center',
    justifyContent: 'center',
  },
  neoBox: {
    //flex: 1,
    //backgroundColor: '#dfdfdf',
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'center',
    width: 195,
    //maxHeight: 200,
    alignSelf: 'center',
    //borderRadius: ,
  },
});
